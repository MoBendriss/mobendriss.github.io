import { AppProvider, useApp } from './context/AppContext';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';
import HomeTab from './components/tabs/HomeTab';
import AboutTab from './components/tabs/AboutTab';
import MathTab from './components/tabs/MathTab';
import ResearchTab from './components/tabs/ResearchTab';
import FAQTab from './components/tabs/FAQTab';
import ContactTab from './components/tabs/ContactTab';
import PrivacyTab from './components/tabs/PrivacyTab';

function MainContent() {
  const { activeTab } = useApp();

  const renderTab = () => {
    switch (activeTab) {
      case 'accueil':
        return <HomeTab />;
      case 'apropos':
        return <AboutTab />;
      case 'mathematiques':
        return <MathTab />;
      case 'recherche':
        return <ResearchTab />;
      case 'faq':
        return <FAQTab />;
      case 'contact':
        return <ContactTab />;
      case 'confidentialite':
        return <PrivacyTab />;
      default:
        return <HomeTab />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors">
      {/* Skip link */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:bg-amber-500 focus:text-white focus:px-4 focus:py-2 focus:rounded-lg"
      >
        Aller au contenu principal
      </a>

      {/* Background glyphs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none select-none opacity-[0.02] dark:opacity-[0.015] z-0">
        <span className="absolute top-[10%] left-[5%] text-[200px] font-serif">∞</span>
        <span className="absolute top-[30%] right-[10%] text-[180px] font-serif">∂</span>
        <span className="absolute bottom-[20%] left-[15%] text-[150px] font-serif">≈</span>
        <span className="absolute bottom-[40%] right-[5%] text-[170px] font-serif">∴</span>
        <span className="absolute top-[60%] left-[40%] text-[190px] font-serif">Ω</span>
      </div>

      <Header />
      <Navigation />

      <main className="container mx-auto px-4 py-8 relative z-10" id="main-content">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main content */}
          <div className="flex-1 min-w-0">
            {renderTab()}
          </div>

          {/* Sidebar - hide on contact and privacy pages */}
          {!['contact', 'confidentialite'].includes(activeTab) && (
            <div className="w-full lg:w-80 flex-shrink-0">
              <Sidebar />
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
