export type Language = 'fr' | 'ar';

export const translations = {
  fr: {
    // Navigation
    'nav.accueil': 'Accueil',
    'nav.apropos': 'À propos',
    'nav.maths': 'Mathématiques',
    'nav.recherche': 'Recherche',
    'nav.faq': 'FAQ',
    'nav.contact': 'Contact',
    
    // Header
    'eyebrow': 'Enseignant de mathématiques',
    'tagline': 'Plateforme académique des mathématiques',
    
    // Hero
    'hero.kicker': 'Plateforme académique gratuite',
    'hero.title': 'Apprenez les mathématiques avec rigueur et clarté.',
    'hero.description': 'Cours structurés, exercices progressifs, examens corrigés et ressources avancées pour les cycles secondaire et supérieur.',
    'hero.start': 'Commencer',
    'hero.research': 'Recherche',
    
    // Stats
    'stats.cycles': 'Cycles éducatifs',
    'stats.resources': 'Ressources évolutives',
    'stats.languages': 'Langues',
    
    // À propos
    'apropos.heading': 'À propos',
    'apropos.bio': 'Enseignant de mathématiques passionné par la pédagogie et la transmission des savoirs. Cette plateforme regroupe des ressources gratuites pour les élèves et les étudiants.',
    'apropos.domaines': 'Domaines d\'expertise',
    'apropos.tag1': 'Algèbre',
    'apropos.tag2': 'Analyse',
    'apropos.tag3': 'Géométrie',
    'apropos.tag4': 'Didactique',
    
    // Mathématiques
    'maths.heading': 'Mathématiques',
    'maths.sub': 'Explorez les ressources par cycle et par type.',
    
    // Filtres
    'filter.allCycles': 'Tous les cycles',
    'filter.college': 'Collège',
    'filter.lycee': 'Lycée',
    'filter.superieur': 'Supérieur',
    'filter.allTypes': 'Tous les types',
    'filter.cours': 'Cours',
    'filter.td': 'TD',
    'filter.exam': 'Examens',
    'filter.recherche': 'Recherche',
    'filter.favorites': 'Favoris',
    'filter.noResults': 'Aucun résultat trouvé.',
    'filter.results': 'ressource(s) trouvée(s)',
    
    // Recherche
    'recherche.heading': 'Recherche & Supérieur',
    'recherche.sub': 'Ressources avancées pour les étudiants du supérieur.',
    
    // FAQ
    'faq.heading': 'Questions fréquentes',
    'faq.q1': 'Comment télécharger un document ?',
    'faq.a1': 'Cliquez sur le bouton « Télécharger » de la ressource souhaitée.',
    'faq.q2': 'Les ressources sont-elles gratuites ?',
    'faq.a2': 'Oui, toutes les ressources sont gratuites et libres d\'usage pédagogique.',
    'faq.q3': 'Comment vous contacter ?',
    'faq.a3': 'Utilisez le formulaire de l\'onglet Contact.',
    'faq.q4': 'Les cours sont-ils adaptés au programme marocain ?',
    'faq.a4': 'Oui, tous les cours suivent le programme officiel du ministère de l\'éducation nationale.',
    'faq.q5': 'Puis-je contribuer au contenu ?',
    'faq.a5': 'Oui, contactez-moi via le formulaire pour proposer vos contributions.',
    
    // Contact
    'contact.heading': 'Contact',
    'contact.intro': 'Pour toute question ou collaboration, écrivez-moi.',
    'contact.nameLabel': 'Nom',
    'contact.emailLabel': 'E-mail',
    'contact.messageLabel': 'Message',
    'contact.submit': 'Envoyer',
    'contact.namePlaceholder': 'Votre nom',
    'contact.emailPlaceholder': 'nom@exemple.com',
    'contact.messagePlaceholder': 'Votre message...',
    
    // Sidebar
    'sidebar.mathBtn': 'Mathématiques',
    'sidebar.researchBtn': 'Recherche',
    'sidebar.newsTitle': 'Actualités',
    'sidebar.newBadge': 'Nouveau',
    'sidebar.news1': 'Mise en ligne des ressources pour le cycle collégial.',
    'sidebar.news2': 'Ajout des séries d\'exercices pour la 1ère BAC.',
    
    // Footer
    'footer.rights': '© 2026 MoBendriss. Tous droits réservés.',
    'footer.tagline': 'Conçu avec rigueur.',
    'footer.legalLink': 'Confidentialité',
    
    // Legal
    'legal.heading': 'Confidentialité',
    'legal.privacy1': 'Aucune donnée personnelle n\'est collectée en dehors du formulaire de contact.',
    
    // Search
    'search.placeholder': 'Rechercher…',
    
    // Accessibility
    'accessibility.skip': 'Aller au contenu principal',
    'accessibility.darkMode': 'Mode sombre',
    'accessibility.lightMode': 'Mode clair',
    'accessibility.switchToArabic': 'Passer en arabe',
    'accessibility.switchToFrench': 'Passer en français',
    
    // Resources
    'resource.download': 'Télécharger',
    'resource.view': 'Voir',
  },
  ar: {
    // Navigation
    'nav.accueil': 'الرئيسية',
    'nav.apropos': 'نبذة',
    'nav.maths': 'الرياضيات',
    'nav.recherche': 'البحث',
    'nav.faq': 'الأسئلة',
    'nav.contact': 'اتصل بنا',
    
    // Header
    'eyebrow': 'أستاذ الرياضيات',
    'tagline': 'منصة أكاديمية للرياضيات',
    
    // Hero
    'hero.kicker': 'منصة أكاديمية مجانية',
    'hero.title': 'تعلّم الرياضيات بدقة ووضوح.',
    'hero.description': 'دروس منظمة، تمارين تدريجية، امتحانات مصححة وموارد متقدمة للتعليم الثانوي والعالي.',
    'hero.start': 'ابدأ الآن',
    'hero.research': 'البحث',
    
    // Stats
    'stats.cycles': 'أسلاك تعليمية',
    'stats.resources': 'موارد متطورة',
    'stats.languages': 'لغات',
    
    // À propos
    'apropos.heading': 'نبذة',
    'apropos.bio': 'أستاذ رياضيات شغوف بالتربية ونقل المعرفة. تجمع هذه المنصة موارد مجانية للتلاميذ والطلبة.',
    'apropos.domaines': 'مجالات الخبرة',
    'apropos.tag1': 'الجبر',
    'apropos.tag2': 'التحليل',
    'apropos.tag3': 'الهندسة',
    'apropos.tag4': 'الديداكتيك',
    
    // Mathématiques
    'maths.heading': 'الرياضيات',
    'maths.sub': 'استكشف الموارد حسب السلك والنوع.',
    
    // Filtres
    'filter.allCycles': 'جميع الأسلاك',
    'filter.college': 'الإعدادي',
    'filter.lycee': 'الثانوي',
    'filter.superieur': 'العالي',
    'filter.allTypes': 'جميع الأنواع',
    'filter.cours': 'دروس',
    'filter.td': 'تمارين',
    'filter.exam': 'امتحانات',
    'filter.recherche': 'بحث',
    'filter.favorites': 'المفضلة',
    'filter.noResults': 'لا توجد نتائج.',
    'filter.results': 'مورد (موارد) موجودة',
    
    // Recherche
    'recherche.heading': 'البحث والتعليم العالي',
    'recherche.sub': 'موارد متقدمة لطلبة التعليم العالي.',
    
    // FAQ
    'faq.heading': 'الأسئلة الشائعة',
    'faq.q1': 'كيف أحمّل مستندًا؟',
    'faq.a1': 'انقر على زر « تحميل » للمورد المطلوب.',
    'faq.q2': 'هل الموارد مجانية؟',
    'faq.a2': 'نعم، جميع الموارد مجانية ومتاحة للاستخدام التعليمي.',
    'faq.q3': 'كيف يمكنني التواصل معكم؟',
    'faq.a3': 'استخدم نموذج التواصل في قسم اتصل بنا.',
    'faq.q4': 'هل الدروس متوافقة مع البرنامج المغربي؟',
    'faq.a4': 'نعم، جميع الدروس تتبع البرنامج الرسمي لوزارة التربية الوطنية.',
    'faq.q5': 'هل يمكنني المساهمة في المحتوى؟',
    'faq.a5': 'نعم، تواصل معي عبر النموذج لاقتراح مساهماتك.',
    
    // Contact
    'contact.heading': 'اتصل بنا',
    'contact.intro': 'لأي سؤال أو تعاون، راسلني.',
    'contact.nameLabel': 'الاسم',
    'contact.emailLabel': 'البريد الإلكتروني',
    'contact.messageLabel': 'الرسالة',
    'contact.submit': 'إرسال',
    'contact.namePlaceholder': 'اسمك',
    'contact.emailPlaceholder': 'nom@exemple.com',
    'contact.messagePlaceholder': 'رسالتك...',
    
    // Sidebar
    'sidebar.mathBtn': 'الرياضيات',
    'sidebar.researchBtn': 'البحث',
    'sidebar.newsTitle': 'الأخبار',
    'sidebar.newBadge': 'جديد',
    'sidebar.news1': 'تم نشر موارد السلك الإعدادي.',
    'sidebar.news2': 'إضافة سلاسل التمارين للأولى باكالوريا.',
    
    // Footer
    'footer.rights': '© 2026 MoBendriss. جميع الحقوق محفوظة.',
    'footer.tagline': 'صُمّم بدقة.',
    'footer.legalLink': 'الخصوصية',
    
    // Legal
    'legal.heading': 'الخصوصية',
    'legal.privacy1': 'لا يتم جمع أي بيانات شخصية خارج نموذج الاتصال.',
    
    // Search
    'search.placeholder': 'بحث…',
    
    // Accessibility
    'accessibility.skip': 'انتقل إلى المحتوى الرئيسي',
    'accessibility.darkMode': 'الوضع الداكن',
    'accessibility.lightMode': 'الوضع الفاتح',
    'accessibility.switchToArabic': 'التبديل إلى العربية',
    'accessibility.switchToFrench': 'التبديل إلى الفرنسية',
    
    // Resources
    'resource.download': 'تحميل',
    'resource.view': 'عرض',
  }
};

export function t(key: string, lang: Language): string {
  const langTranslations = translations[lang] as Record<string, string>;
  return langTranslations[key] || key;
}
