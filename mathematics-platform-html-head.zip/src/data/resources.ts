export interface Resource {
  id: string;
  title: {
    fr: string;
    ar: string;
  };
  cycle: 'college' | 'lycee' | 'superieur';
  type: 'cours' | 'td' | 'exam' | 'recherche';
  icon: string;
  url: string;
  tags: string[];
  featured?: boolean;
}

export const resources: Resource[] = [
  // Collège
  {
    id: '1',
    title: { fr: 'Arithmétique - Cours complet', ar: 'الحساب - درس كامل' },
    cycle: 'college',
    type: 'cours',
    icon: 'fa-solid fa-book',
    url: '#',
    tags: ['arithmétique', 'nombres', 'collège'],
  },
  {
    id: '2',
    title: { fr: 'Géométrie plane - Exercices', ar: 'الهندسة المستوية - تمارين' },
    cycle: 'college',
    type: 'td',
    icon: 'fa-solid fa-shapes',
    url: '#',
    tags: ['géométrie', 'exercices'],
  },
  {
    id: '3',
    title: { fr: 'Examen régional - 3ème collège', ar: 'الامتحان الجهوي - الثالثة إعدادي' },
    cycle: 'college',
    type: 'exam',
    icon: 'fa-solid fa-file-lines',
    url: '#',
    tags: ['examen', 'régional'],
  },
  
  // Lycée
  {
    id: '4',
    title: { fr: 'Analyse - Fonctions et limites', ar: 'التحليل - الدوال والنهايات' },
    cycle: 'lycee',
    type: 'cours',
    icon: 'fa-solid fa-wave-square',
    url: '#',
    tags: ['analyse', 'fonctions', 'limites'],
    featured: true,
  },
  {
    id: '5',
    title: { fr: 'Algèbre - Suites numériques', ar: 'الجبر - المتتاليات العددية' },
    cycle: 'lycee',
    type: 'cours',
    icon: 'fa-solid fa-list-ol',
    url: '#',
    tags: ['algèbre', 'suites'],
  },
  {
    id: '6',
    title: { fr: 'TD - Intégrales', ar: 'تمارين - التكاملات' },
    cycle: 'lycee',
    type: 'td',
    icon: 'fa-solid fa-integral',
    url: '#',
    tags: ['intégrales', 'exercices'],
  },
  {
    id: '7',
    title: { fr: 'TD - Probabilités', ar: 'تمارين - الاحتمالات' },
    cycle: 'lycee',
    type: 'td',
    icon: 'fa-solid fa-dice',
    url: '#',
    tags: ['probabilités', 'exercices'],
  },
  {
    id: '8',
    title: { fr: 'Bac - Sciences Math 2024', ar: 'باكالوريا - علوم رياضية 2024' },
    cycle: 'lycee',
    type: 'exam',
    icon: 'fa-solid fa-award',
    url: '#',
    tags: ['bac', 'sciences math'],
    featured: true,
  },
  {
    id: '9',
    title: { fr: 'Bac - Sciences Ex 2024', ar: 'باكالوريا - علوم تجريبية 2024' },
    cycle: 'lycee',
    type: 'exam',
    icon: 'fa-solid fa-award',
    url: '#',
    tags: ['bac', 'sciences ex'],
  },
  
  // Supérieur
  {
    id: '10',
    title: { fr: 'Algèbre linéaire avancée', ar: 'الجبر الخطي المتقدم' },
    cycle: 'superieur',
    type: 'cours',
    icon: 'fa-solid fa-vector-square',
    url: '#',
    tags: ['algèbre linéaire', 'matrices'],
  },
  {
    id: '11',
    title: { fr: 'Analyse complexe', ar: 'التحليل المركب' },
    cycle: 'superieur',
    type: 'cours',
    icon: 'fa-solid fa-infinity',
    url: '#',
    tags: ['analyse complexe', 'fonctions holomorphes'],
  },
  {
    id: '12',
    title: { fr: 'Topologie générale', ar: 'التبولوجيا العامة' },
    cycle: 'superieur',
    type: 'cours',
    icon: 'fa-solid fa-circle-nodes',
    url: '#',
    tags: ['topologie', 'espaces métriques'],
    featured: true,
  },
  {
    id: '13',
    title: { fr: 'Théorie des groupes', ar: 'نظرية الزمر' },
    cycle: 'superieur',
    type: 'recherche',
    icon: 'fa-solid fa-diagram-project',
    url: '#',
    tags: ['groupes', 'algèbre'],
  },
  {
    id: '14',
    title: { fr: 'Introduction à la théorie des nombres', ar: 'مدخل إلى نظرية الأعداد' },
    cycle: 'superieur',
    type: 'recherche',
    icon: 'fa-solid fa-calculator',
    url: '#',
    tags: ['théorie des nombres', 'arithmétique'],
  },
  {
    id: '15',
    title: { fr: 'Équations aux dérivées partielles', ar: 'المعادلات التفاضلية الجزئية' },
    cycle: 'superieur',
    type: 'cours',
    icon: 'fa-solid fa-subscript',
    url: '#',
    tags: ['EDP', 'analyse'],
  },
  // More College resources
  {
    id: '16',
    title: { fr: 'Fractions et décimaux', ar: 'الكسور والأعداد العشرية' },
    cycle: 'college',
    type: 'cours',
    icon: 'fa-solid fa-divide',
    url: '#',
    tags: ['fractions', 'décimaux'],
  },
  {
    id: '17',
    title: { fr: 'TD - Équations du 1er degré', ar: 'تمارين - معادلات الدرجة الأولى' },
    cycle: 'college',
    type: 'td',
    icon: 'fa-solid fa-pen-ruler',
    url: '#',
    tags: ['équations', 'algèbre'],
  },
  // More Lycée resources
  {
    id: '18',
    title: { fr: 'Dérivation et applications', ar: 'الاشتقاق وتطبيقاته' },
    cycle: 'lycee',
    type: 'cours',
    icon: 'fa-solid fa-chart-line',
    url: '#',
    tags: ['dérivation', 'analyse'],
    featured: true,
  },
  {
    id: '19',
    title: { fr: 'Géométrie dans l\'espace', ar: 'الهندسة الفضائية' },
    cycle: 'lycee',
    type: 'cours',
    icon: 'fa-solid fa-cube',
    url: '#',
    tags: ['géométrie', 'espace'],
  },
  {
    id: '20',
    title: { fr: 'TD - Nombres complexes', ar: 'تمارين - الأعداد المركبة' },
    cycle: 'lycee',
    type: 'td',
    icon: 'fa-solid fa-i-cursor',
    url: '#',
    tags: ['complexes', 'algèbre'],
  },
];

export const researchResources = resources.filter(r => r.cycle === 'superieur');
