import { Resource } from '../data/resources';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/translations';

interface ResourceCardProps {
  resource: Resource;
}

const cycleColors = {
  college: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  lycee: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  superieur: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
};

const typeIcons = {
  cours: 'fa-solid fa-book',
  td: 'fa-solid fa-pen-ruler',
  exam: 'fa-solid fa-file-lines',
  recherche: 'fa-solid fa-microscope',
};

export default function ResourceCard({ resource }: ResourceCardProps) {
  const { language, favorites, toggleFavorite } = useApp();
  const isFavorite = favorites.includes(resource.id);

  return (
    <article className="group relative bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5 hover:border-amber-300 dark:hover:border-amber-600 hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300 hover:-translate-y-1">
      {/* Featured badge */}
      {resource.featured && (
        <span className="absolute -top-2 -right-2 rtl:-left-2 rtl:right-auto bg-amber-500 text-white text-xs px-2 py-1 rounded-full font-medium shadow-lg">
          <i className="fa-solid fa-star"></i>
        </span>
      )}

      <div className="flex items-start justify-between gap-3 mb-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${cycleColors[resource.cycle]}`}>
          <i className={typeIcons[resource.type]}></i>
        </div>
        <button
          onClick={() => toggleFavorite(resource.id)}
          className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
            isFavorite 
              ? 'text-amber-500 bg-amber-100 dark:bg-amber-900/30' 
              : 'text-slate-400 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20'
          }`}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <i className={isFavorite ? 'fa-solid fa-star' : 'fa-regular fa-star'}></i>
        </button>
      </div>

      <h4 className="font-semibold text-slate-900 dark:text-white mb-3 line-clamp-2 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
        {resource.title[language]}
      </h4>

      <div className="flex items-center justify-between">
        <span className={`text-xs px-2 py-1 rounded-full ${cycleColors[resource.cycle]}`}>
          {t(`filter.${resource.cycle}`, language)}
        </span>
        <a
          href={resource.url}
          className="inline-flex items-center gap-1.5 text-sm text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-medium"
        >
          <i className="fa-solid fa-download"></i>
          {t('resource.download', language)}
        </a>
      </div>
    </article>
  );
}
