import { useApp } from '../context/AppContext';
import { t } from '../i18n/translations';

const tabs = [
  { id: 'accueil', icon: 'fa-solid fa-house', labelKey: 'nav.accueil' },
  { id: 'apropos', icon: 'fa-solid fa-user', labelKey: 'nav.apropos' },
  { id: 'mathematiques', icon: 'fa-solid fa-infinity', labelKey: 'nav.maths' },
  { id: 'recherche', icon: 'fa-solid fa-graduation-cap', labelKey: 'nav.recherche' },
  { id: 'faq', icon: 'fa-solid fa-circle-question', labelKey: 'nav.faq' },
  { id: 'contact', icon: 'fa-solid fa-envelope', labelKey: 'nav.contact' },
] as const;

export default function Navigation() {
  const { 
    activeTab, 
    setActiveTab, 
    theme, 
    toggleTheme, 
    language, 
    toggleLanguage,
    searchQuery,
    setSearchQuery 
  } = useApp();

  return (
    <nav className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between gap-4 py-2">
          {/* Tab buttons */}
          <div className="flex-1 overflow-x-auto scrollbar-hide">
            <ul className="flex items-center gap-1 min-w-max" role="tablist">
              {tabs.map(tab => (
                <li key={tab.id}>
                  <button
                    role="tab"
                    aria-selected={activeTab === tab.id}
                    aria-controls={`content-${tab.id}`}
                    onClick={() => setActiveTab(tab.id as typeof activeTab)}
                    className={`
                      flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                      ${activeTab === tab.id 
                        ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' 
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }
                    `}
                  >
                    <i className={tab.icon}></i>
                    <span className="hidden sm:inline">{t(tab.labelKey, language)}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Search */}
          <div className="hidden md:flex items-center relative">
            <i className="fa-solid fa-magnifying-glass absolute left-3 text-slate-400 dark:text-slate-500 text-sm pointer-events-none"></i>
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('search.placeholder', language)}
              className="pl-9 pr-4 py-2 w-48 lg:w-64 bg-slate-100 dark:bg-slate-800 border-0 rounded-lg text-sm text-slate-700 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-amber-500 focus:outline-none transition-all"
              aria-label={t('search.placeholder', language)}
            />
          </div>

          {/* Toggles */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors font-semibold text-sm"
              aria-label={language === 'fr' ? t('accessibility.switchToArabic', language) : t('accessibility.switchToFrench', language)}
            >
              {language === 'fr' ? 'AR' : 'FR'}
            </button>
            <button
              onClick={toggleTheme}
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              aria-label={theme === 'light' ? t('accessibility.darkMode', language) : t('accessibility.lightMode', language)}
            >
              <i className={theme === 'light' ? 'fa-solid fa-moon' : 'fa-solid fa-sun'}></i>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
