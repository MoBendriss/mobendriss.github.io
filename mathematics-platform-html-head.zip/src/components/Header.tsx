import { useApp } from '../context/AppContext';
import { t } from '../i18n/translations';

export default function Header() {
  const { language } = useApp();

  return (
    <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 text-white py-12 md:py-16">
      {/* Animated gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 via-transparent to-blue-500/5 animate-gradient"></div>
      
      {/* Background glyphs */}
      <div className="absolute inset-0 overflow-hidden opacity-10 pointer-events-none select-none">
        <span className="absolute top-4 left-[10%] text-6xl font-serif floating-glyph">∫</span>
        <span className="absolute top-8 left-[30%] text-5xl font-serif floating-glyph" style={{animationDelay: '0.5s'}}>∑</span>
        <span className="absolute top-6 right-[25%] text-7xl font-serif floating-glyph" style={{animationDelay: '1s'}}>π</span>
        <span className="absolute bottom-8 left-[20%] text-5xl font-serif floating-glyph" style={{animationDelay: '1.5s'}}>√</span>
        <span className="absolute bottom-4 right-[15%] text-6xl font-serif floating-glyph" style={{animationDelay: '2s'}}>Δ</span>
      </div>

      {/* Formula decoration */}
      <div className="absolute top-4 right-4 md:right-8 text-amber-400/30 font-mono text-sm hidden md:block">
        ∀ε&gt;0, ∃δ&gt;0
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 md:gap-8">
          <div className="text-center md:text-start rtl:md:text-end">
            <p className="text-amber-400 font-medium text-sm tracking-wide uppercase mb-2">
              {t('eyebrow', language)}
            </p>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-3 flex items-center justify-center md:justify-start rtl:md:justify-end gap-3">
              <span className="italic text-white">Mo</span>
              <span className="text-amber-100">Bendriss</span>
              <span className="inline-flex items-center justify-center w-6 h-6 bg-amber-500 rounded-full text-slate-900 text-xs">
                <i className="fa-solid fa-check"></i>
              </span>
            </h1>
            <p className="text-slate-300 text-lg">
              {t('tagline', language)}
            </p>
          </div>

          {/* Logo avatar */}
          <div className="flex-shrink-0">
            <svg viewBox="0 0 100 100" className="w-24 h-24 md:w-32 md:h-32">
              <defs>
                <linearGradient id="logoFill" x1="10%" y1="0%" x2="90%" y2="100%">
                  <stop offset="0%" stopColor="#26496A"/>
                  <stop offset="100%" stopColor="#0C1526"/>
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="47" fill="url(#logoFill)" stroke="#E7A947" strokeWidth="1.4"/>
              <circle cx="50" cy="50" r="40" fill="none" stroke="#E7A947" strokeOpacity="0.35" strokeWidth="0.7"/>
              <text x="50" y="63" textAnchor="middle" fontFamily="Fraunces, Georgia, serif" fontStyle="italic" fontWeight="600" fontSize="32" fill="#FBF8F2" letterSpacing="-1">MB</text>
              <line x1="33" y1="70" x2="67" y2="70" stroke="#E7A947" strokeWidth="1" strokeOpacity="0.75"/>
              <text x="50" y="80" textAnchor="middle" fontFamily="'IBM Plex Mono', monospace" fontSize="6.2" letterSpacing="2.5" fill="#DCE4F0" opacity="0.8">MATHS</text>
            </svg>
          </div>
        </div>
      </div>
    </header>
  );
}
