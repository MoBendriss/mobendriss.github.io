import { useApp } from '../context/AppContext';
import { t } from '../i18n/translations';

export default function Footer() {
  const { language, setActiveTab } = useApp();

  return (
    <footer className="bg-slate-900 dark:bg-slate-950 text-slate-400 py-10 mt-12">
      <div className="container mx-auto px-4">
        {/* Footer top */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <svg viewBox="0 0 100 100" className="w-12 h-12">
              <defs>
                <linearGradient id="footerLogoFill" x1="10%" y1="0%" x2="90%" y2="100%">
                  <stop offset="0%" stopColor="#26496A"/>
                  <stop offset="100%" stopColor="#0C1526"/>
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="47" fill="url(#footerLogoFill)" stroke="#E7A947" strokeWidth="1.4"/>
              <text x="50" y="60" textAnchor="middle" fontFamily="Fraunces, Georgia, serif" fontStyle="italic" fontWeight="600" fontSize="28" fill="#FBF8F2">MB</text>
            </svg>
            <div>
              <span className="font-serif text-white text-lg font-semibold">MoBendriss</span>
              <p className="text-sm text-slate-500">{t('tagline', language)}</p>
            </div>
          </div>
          
          {/* Quick links */}
          <div className="flex items-center gap-6">
            <button onClick={() => setActiveTab('accueil')} className="text-slate-400 hover:text-amber-500 transition-colors text-sm">
              {t('nav.accueil', language)}
            </button>
            <button onClick={() => setActiveTab('mathematiques')} className="text-slate-400 hover:text-amber-500 transition-colors text-sm">
              {t('nav.maths', language)}
            </button>
            <button onClick={() => setActiveTab('contact')} className="text-slate-400 hover:text-amber-500 transition-colors text-sm">
              {t('nav.contact', language)}
            </button>
          </div>
        </div>

        {/* Footer bottom */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8">
          <p className="text-center md:text-start rtl:md:text-end text-sm">
            <span>{t('footer.rights', language)}</span>
            {' '}
            <span className="text-amber-500">{t('footer.tagline', language)}</span>
          </p>
          <div className="flex items-center gap-4">
            <a 
              href="https://github.com/mobendriss" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-white transition-colors"
            >
              <i className="fa-brands fa-github text-lg"></i>
            </a>
            <button
              onClick={() => setActiveTab('confidentialite')}
              className="text-slate-400 hover:text-amber-500 transition-colors text-sm"
            >
              {t('footer.legalLink', language)}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
