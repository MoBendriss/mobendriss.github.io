import { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { resources } from '../../data/resources';
import ResourceCard from '../ResourceCard';

export default function MathTab() {
  const { language, favorites, searchQuery } = useApp();
  const [cycleFilter, setCycleFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const filteredResources = useMemo(() => {
    return resources.filter(resource => {
      // Cycle filter
      if (cycleFilter !== 'all' && resource.cycle !== cycleFilter) return false;
      
      // Type filter
      if (typeFilter !== 'all' && resource.type !== typeFilter) return false;
      
      // Favorites filter
      if (showFavoritesOnly && !favorites.includes(resource.id)) return false;
      
      // Search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const titleMatch = resource.title.fr.toLowerCase().includes(query) ||
                          resource.title.ar.includes(query);
        const tagMatch = resource.tags.some(tag => tag.toLowerCase().includes(query));
        if (!titleMatch && !tagMatch) return false;
      }
      
      return true;
    });
  }, [cycleFilter, typeFilter, showFavoritesOnly, favorites, searchQuery]);

  return (
    <div className="space-y-6 relative">
      {/* Watermark */}
      <span className="absolute -right-4 top-0 text-[150px] font-serif text-slate-100 dark:text-slate-800/50 select-none pointer-events-none">
        ∞
      </span>

      <div className="relative z-10">
        <h2 className="text-2xl md:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-3">
          <i className="fa-solid fa-infinity text-amber-500"></i>
          {t('maths.heading', language)}
        </h2>
        <p className="text-slate-600 dark:text-slate-400 mb-6">
          {t('maths.sub', language)}
        </p>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-6 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
          <div className="relative flex-1 min-w-[200px] md:hidden">
            <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input
              type="search"
              placeholder={t('search.placeholder', language)}
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <select
            value={cycleFilter}
            onChange={(e) => setCycleFilter(e.target.value)}
            className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-sm text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-amber-500 focus:outline-none"
          >
            <option value="all">{t('filter.allCycles', language)}</option>
            <option value="college">{t('filter.college', language)}</option>
            <option value="lycee">{t('filter.lycee', language)}</option>
            <option value="superieur">{t('filter.superieur', language)}</option>
          </select>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-sm text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-amber-500 focus:outline-none"
          >
            <option value="all">{t('filter.allTypes', language)}</option>
            <option value="cours">{t('filter.cours', language)}</option>
            <option value="td">{t('filter.td', language)}</option>
            <option value="exam">{t('filter.exam', language)}</option>
            <option value="recherche">{t('filter.recherche', language)}</option>
          </select>

          <button
            onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              showFavoritesOnly 
                ? 'bg-amber-500 text-white' 
                : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 hover:bg-amber-50 dark:hover:bg-slate-600'
            }`}
          >
            <i className={showFavoritesOnly ? 'fa-solid fa-star' : 'fa-regular fa-star'}></i>
            {t('filter.favorites', language)}
          </button>
        </div>

        {/* Results count */}
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          {filteredResources.length} {t('filter.results', language)}
        </p>

        {/* Resources grid */}
        {filteredResources.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredResources.map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
            <i className="fa-solid fa-folder-open text-4xl text-slate-300 dark:text-slate-600 mb-4"></i>
            <p className="text-slate-500 dark:text-slate-400">{t('filter.noResults', language)}</p>
          </div>
        )}
      </div>
    </div>
  );
}
