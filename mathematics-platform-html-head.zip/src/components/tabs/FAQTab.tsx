import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

const faqItems = [
  { q: 'faq.q1', a: 'faq.a1', icon: 'fa-solid fa-download' },
  { q: 'faq.q2', a: 'faq.a2', icon: 'fa-solid fa-gift' },
  { q: 'faq.q3', a: 'faq.a3', icon: 'fa-solid fa-envelope' },
  { q: 'faq.q4', a: 'faq.a4', icon: 'fa-solid fa-book' },
  { q: 'faq.q5', a: 'faq.a5', icon: 'fa-solid fa-handshake' },
];

export default function FAQTab() {
  const { language } = useApp();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="space-y-6 relative">
      {/* Watermark */}
      <span className="absolute -right-4 top-0 text-[150px] font-serif text-slate-100 dark:text-slate-800/50 select-none pointer-events-none">
        ?
      </span>

      <div className="relative z-10">
        <h2 className="text-2xl md:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-3">
          <i className="fa-solid fa-circle-question text-amber-500"></i>
          {t('faq.heading', language)}
        </h2>

        <div className="space-y-3">
          {faqItems.map((item, index) => (
            <details
              key={index}
              open={openIndex === index}
              onToggle={(e) => {
                if ((e.target as HTMLDetailsElement).open) {
                  setOpenIndex(index);
                } else if (openIndex === index) {
                  setOpenIndex(null);
                }
              }}
              className="group bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden"
            >
              <summary className="flex items-center justify-between p-5 cursor-pointer list-none hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                <span className="flex items-center gap-3 font-medium text-slate-900 dark:text-white">
                  <i className={`${item.icon} text-amber-500`}></i>
                  {t(item.q, language)}
                </span>
                <i className="fa-solid fa-chevron-down text-slate-400 transition-transform group-open:rotate-180"></i>
              </summary>
              <div className="px-5 pb-5 text-slate-600 dark:text-slate-300">
                {t(item.a, language)}
              </div>
            </details>
          ))}
        </div>
      </div>
    </div>
  );
}
