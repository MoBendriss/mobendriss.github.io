import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';
import { researchResources } from '../../data/resources';
import ResourceCard from '../ResourceCard';

export default function ResearchTab() {
  const { language } = useApp();

  return (
    <div className="space-y-6 relative">
      {/* Watermark */}
      <span className="absolute -right-4 top-0 text-[150px] font-serif text-slate-100 dark:text-slate-800/50 select-none pointer-events-none">
        ∫
      </span>

      <div className="relative z-10">
        <h2 className="text-2xl md:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-3">
          <i className="fa-solid fa-graduation-cap text-amber-500"></i>
          {t('recherche.heading', language)}
        </h2>
        <p className="text-slate-600 dark:text-slate-400 mb-6">
          {t('recherche.sub', language)}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {researchResources.map(resource => (
            <ResourceCard key={resource.id} resource={resource} />
          ))}
        </div>
      </div>
    </div>
  );
}
