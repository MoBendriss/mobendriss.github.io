import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export default function ContactTab() {
  const { language } = useApp();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    
    try {
      const response = await fetch('https://formsubmit.co/ajax/mobendriss@hotmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          _subject: 'Message depuis mobendriss.github.io',
        }),
      });

      if (response.ok) {
        setStatus('sent');
        setFormData({ name: '', email: '', message: '' });
        setTimeout(() => setStatus('idle'), 3000);
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <section className="bg-white dark:bg-slate-800 rounded-2xl p-8 border border-slate-200 dark:border-slate-700">
        <h2 className="text-2xl md:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-3">
          <i className="fa-solid fa-paper-plane text-amber-500"></i>
          {t('contact.heading', language)}
        </h2>
        <p className="text-slate-600 dark:text-slate-400 mb-8">
          {t('contact.intro', language)}
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                {t('contact.nameLabel', language)}
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder={t('contact.namePlaceholder', language)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                {t('contact.emailLabel', language)}
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder={t('contact.emailPlaceholder', language)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label htmlFor="message" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              {t('contact.messageLabel', language)}
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder={t('contact.messagePlaceholder', language)}
              className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none transition-all resize-none"
            />
          </div>

          <div className="flex items-center justify-end">
            <button
              type="submit"
              disabled={status === 'sending'}
              className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 disabled:bg-amber-400 text-white px-8 py-3 rounded-lg font-medium transition-colors shadow-lg shadow-amber-500/25"
            >
              {status === 'sending' ? (
                <>
                  <i className="fa-solid fa-spinner animate-spin"></i>
                  {language === 'fr' ? 'Envoi...' : 'جاري الإرسال...'}
                </>
              ) : status === 'sent' ? (
                <>
                  <i className="fa-solid fa-check"></i>
                  {language === 'fr' ? 'Envoyé !' : 'تم الإرسال!'}
                </>
              ) : (
                <>
                  {t('contact.submit', language)}
                  <i className="fa-regular fa-paper-plane"></i>
                </>
              )}
            </button>
          </div>

          {status === 'error' && (
            <p className="text-red-500 text-sm text-center">
              {language === 'fr' ? 'Une erreur est survenue. Veuillez réessayer.' : 'حدث خطأ. يرجى المحاولة مرة أخرى.'}
            </p>
          )}
        </form>
      </section>
    </div>
  );
}
