import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export default function AboutTab() {
  const { language } = useApp();

  const tags = ['apropos.tag1', 'apropos.tag2', 'apropos.tag3', 'apropos.tag4'];

  const achievements = [
    { icon: 'fa-solid fa-chalkboard-user', value: '10+', label: language === 'fr' ? 'Années d\'expérience' : 'سنوات خبرة' },
    { icon: 'fa-solid fa-users', value: '500+', label: language === 'fr' ? 'Élèves formés' : 'طالب مدرّس' },
    { icon: 'fa-solid fa-file-lines', value: '100+', label: language === 'fr' ? 'Ressources créées' : 'مورد منشأ' },
  ];

  return (
    <div className="space-y-8 relative">
      {/* Watermark */}
      <span className="absolute -right-4 top-0 text-[150px] font-serif text-slate-100 dark:text-slate-800/50 select-none pointer-events-none">
        Σ
      </span>

      <div className="relative z-10">
        {/* Profile card */}
        <div className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-700">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="flex-shrink-0">
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white text-3xl font-serif font-bold shadow-lg shadow-amber-500/30">
                MB
              </div>
            </div>
            <div className="text-center md:text-start rtl:md:text-end flex-1">
              <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white mb-2">
                {t('apropos.heading', language)}
              </h3>
              <p className="text-amber-600 dark:text-amber-400 font-medium mb-4">
                {t('eyebrow', language)}
              </p>
              <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
                {t('apropos.bio', language)}
              </p>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          {achievements.map((item, idx) => (
            <div key={idx} className="bg-white dark:bg-slate-800 rounded-xl p-4 text-center border border-slate-200 dark:border-slate-700">
              <i className={`${item.icon} text-amber-500 text-2xl mb-2`}></i>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">{item.value}</div>
              <div className="text-sm text-slate-500 dark:text-slate-400">{item.label}</div>
            </div>
          ))}
        </div>

        {/* Expertise */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-2">
            <i className="fa-solid fa-star text-amber-500"></i>
            {t('apropos.domaines', language)}
          </h3>
          <div className="flex flex-wrap gap-3">
            {tags.map((tagKey) => (
              <span
                key={tagKey}
                className="px-4 py-2 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded-full font-medium text-sm hover:scale-105 transition-transform cursor-default"
              >
                {t(tagKey, language)}
              </span>
            ))}
          </div>
        </div>

        {/* Quote */}
        <blockquote className="mt-8 p-6 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-xl border-l-4 border-amber-500">
          <p className="text-lg italic text-slate-700 dark:text-slate-300">
            {language === 'fr' 
              ? '"Les mathématiques ne sont pas une science, mais un langage."'
              : '"الرياضيات ليست علمًا، بل هي لغة."'
            }
          </p>
          <cite className="block mt-2 text-sm text-slate-500 dark:text-slate-400 not-italic">
            — Josiah Willard Gibbs
          </cite>
        </blockquote>
      </div>
    </div>
  );
}
