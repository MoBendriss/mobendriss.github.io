import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export default function PrivacyTab() {
  const { language } = useApp();

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl md:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-3">
        <i className="fa-solid fa-shield-halved text-amber-500"></i>
        {t('legal.heading', language)}
      </h2>

      <div className="bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-700">
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          {t('legal.privacy1', language)}
        </p>
      </div>
    </div>
  );
}
