import { useApp } from '../../context/AppContext';
import { t } from '../../i18n/translations';

export default function HomeTab() {
  const { language, setActiveTab } = useApp();

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 p-8 md:p-12">
        {/* Watermark */}
        <span className="absolute -right-8 -bottom-8 text-[200px] font-serif text-slate-200 dark:text-slate-700/50 select-none pointer-events-none opacity-50">
          ∀
        </span>

        <div className="relative z-10 flex flex-col lg:flex-row items-center gap-8">
          <div className="flex-1 text-center lg:text-start rtl:lg:text-end">
            <span className="inline-flex items-center gap-2 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-3 py-1 rounded-full text-sm font-medium mb-4">
              <i className="fa-solid fa-sparkles"></i>
              {t('hero.kicker', language)}
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-4 leading-tight">
              {t('hero.title', language)}
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-300 mb-6 max-w-2xl">
              {t('hero.description', language)}
            </p>
            <div className="flex flex-wrap items-center justify-center lg:justify-start rtl:lg:justify-end gap-3">
              <button
                onClick={() => setActiveTab('mathematiques')}
                className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-lg shadow-amber-500/25"
              >
                <i className="fa-solid fa-book-open"></i>
                {t('hero.start', language)}
              </button>
              <button
                onClick={() => setActiveTab('recherche')}
                className="inline-flex items-center gap-2 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-700 dark:text-white px-6 py-3 rounded-lg font-medium transition-colors border border-slate-200 dark:border-slate-600"
              >
                <i className="fa-solid fa-graduation-cap"></i>
                {t('hero.research', language)}
              </button>
            </div>
          </div>

          {/* Math equations decoration */}
          <div className="flex-shrink-0 hidden lg:flex flex-col items-center gap-4 text-slate-400 dark:text-slate-500 font-mono">
            <span className="text-lg opacity-60">f : ℝ → ℝ</span>
            <span className="text-3xl text-amber-500 dark:text-amber-400 font-serif">∫<sub>a</sub><sup>b</sup> f(x) dx</span>
            <span className="text-lg opacity-60">lim<sub>x→a</sub> f(x)</span>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 text-center border border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-600 hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300 hover:-translate-y-1 cursor-default">
          <span className="block text-4xl font-bold text-amber-500 mb-2">03</span>
          <span className="text-slate-600 dark:text-slate-400">{t('stats.cycles', language)}</span>
        </div>
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 text-center border border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-600 hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300 hover:-translate-y-1 cursor-default">
          <span className="block text-4xl font-bold text-amber-500 mb-2">∞</span>
          <span className="text-slate-600 dark:text-slate-400">{t('stats.resources', language)}</span>
        </div>
        <div className="bg-white dark:bg-slate-800 rounded-xl p-6 text-center border border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-600 hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300 hover:-translate-y-1 cursor-default">
          <span className="block text-4xl font-bold text-amber-500 mb-2">02</span>
          <span className="text-slate-600 dark:text-slate-400">{t('stats.languages', language)}</span>
        </div>
      </div>

      {/* Featured Resources Preview */}
      <section className="mt-8">
        <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <i className="fa-solid fa-star text-amber-500"></i>
          {language === 'fr' ? 'Ressources populaires' : 'الموارد الشائعة'}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div 
            onClick={() => setActiveTab('mathematiques')}
            className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl p-5 border border-blue-200 dark:border-blue-800 cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          >
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center text-white mb-3">
              <i className="fa-solid fa-graduation-cap"></i>
            </div>
            <h4 className="font-semibold text-blue-900 dark:text-blue-100">{language === 'fr' ? 'Collège' : 'الإعدادي'}</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">{language === 'fr' ? 'Cours et exercices' : 'دروس وتمارين'}</p>
          </div>
          <div 
            onClick={() => setActiveTab('mathematiques')}
            className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-xl p-5 border border-green-200 dark:border-green-800 cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          >
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-white mb-3">
              <i className="fa-solid fa-book-open"></i>
            </div>
            <h4 className="font-semibold text-green-900 dark:text-green-100">{language === 'fr' ? 'Lycée' : 'الثانوي'}</h4>
            <p className="text-sm text-green-700 dark:text-green-300 mt-1">{language === 'fr' ? 'BAC et préparation' : 'الباكالوريا والتحضير'}</p>
          </div>
          <div 
            onClick={() => setActiveTab('recherche')}
            className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-xl p-5 border border-purple-200 dark:border-purple-800 cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          >
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center text-white mb-3">
              <i className="fa-solid fa-flask"></i>
            </div>
            <h4 className="font-semibold text-purple-900 dark:text-purple-100">{language === 'fr' ? 'Supérieur' : 'التعليم العالي'}</h4>
            <p className="text-sm text-purple-700 dark:text-purple-300 mt-1">{language === 'fr' ? 'Recherche avancée' : 'البحث المتقدم'}</p>
          </div>
        </div>
      </section>
    </div>
  );
}
