import { useApp } from '../context/AppContext';
import { t } from '../i18n/translations';

export default function Sidebar() {
  const { language, setActiveTab } = useApp();

  return (
    <aside className="space-y-6">
      {/* Quick actions */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-4 space-y-3">
        <button
          onClick={() => setActiveTab('mathematiques')}
          className="w-full flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-lg font-medium transition-all shadow-lg shadow-amber-500/25"
        >
          <i className="fa-solid fa-infinity"></i>
          {t('sidebar.mathBtn', language)}
        </button>
        <button
          onClick={() => setActiveTab('recherche')}
          className="w-full flex items-center gap-3 px-4 py-3 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-white rounded-lg font-medium transition-colors"
        >
          <i className="fa-solid fa-graduation-cap"></i>
          {t('sidebar.researchBtn', language)}
        </button>
      </div>

      {/* News widget */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5">
        <h4 className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300 mb-4">
          <i className="fa-solid fa-bullhorn text-amber-500"></i>
          {t('sidebar.newsTitle', language)}
        </h4>
        <ul className="space-y-4">
          <li className="relative">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wide">
                {language === 'fr' ? 'JUIL. 2026' : 'يوليو 2026'}
              </span>
              <span className="text-xs bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 px-2 py-0.5 rounded-full font-medium">
                {t('sidebar.newBadge', language)}
              </span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {t('sidebar.news1', language)}
            </p>
          </li>
          <li className="relative border-t border-slate-100 dark:border-slate-700 pt-4">
            <span className="text-xs font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wide mb-1 block">
              {language === 'fr' ? 'JUIN 2026' : 'يونيو 2026'}
            </span>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {t('sidebar.news2', language)}
            </p>
          </li>
        </ul>
      </div>

      {/* Math decorations */}
      <div className="hidden lg:block text-center opacity-30 dark:opacity-20">
        <div className="text-4xl font-serif text-slate-400 space-x-4 rtl:space-x-reverse">
          <span>∂</span>
          <span>∞</span>
          <span>∑</span>
        </div>
      </div>

      {/* Social Links */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-5">
        <h4 className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-300 mb-4">
          <i className="fa-solid fa-share-nodes text-amber-500"></i>
          {language === 'fr' ? 'Suivez-moi' : 'تابعني'}
        </h4>
        <div className="flex items-center gap-3">
          <a 
            href="https://github.com/mobendriss" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-10 h-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-900 hover:text-white dark:hover:bg-white dark:hover:text-slate-900 transition-colors"
          >
            <i className="fa-brands fa-github"></i>
          </a>
          <a 
            href="mailto:mobendriss@hotmail.com" 
            className="w-10 h-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-amber-500 hover:text-white transition-colors"
          >
            <i className="fa-solid fa-envelope"></i>
          </a>
        </div>
      </div>
    </aside>
  );
}
